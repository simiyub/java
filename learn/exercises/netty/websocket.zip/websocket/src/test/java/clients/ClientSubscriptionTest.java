package clients;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ClientSubscriptionTest {

    //ClientSubscription subscription;
    @BeforeEach
    void setUp() {
        //subscription = new
    }

    @Test
    void subscribe() {

    }

    @Test
    void unSubscribe() {
    }
}